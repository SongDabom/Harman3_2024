/*
 * myLib.h
 *
 *  Created on: Apr 17, 2024
 *      Author: SAMSUNG
 */

#ifndef INC_MYLIB_H_
#define INC_MYLIB_H_

int __io_putchar(int ch);
//int GetAdcValue();
void ProgramStart();
void Wait();
void Outs();
void usDelay(int us);
double usDist1();
double usDist2();
double usDist3();
double usDist4();
double usDist5();
void Wait(int o);
int GetSpeedData();

#endif /* INC_MYLIB_H_ */
